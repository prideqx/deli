/*
Navicat MySQL Data Transfer

Source Server         : 10.10.144.11 -6666
Source Server Version : 50720
Source Host           : 10.10.144.11:6666
Source Database       : xcx

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2019-10-25 14:42:08
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `catalog`
-- ----------------------------
DROP TABLE IF EXISTS `catalog`;
CREATE TABLE `catalog` (
  `catalog_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '类别id',
  `catalog_name` varchar(1024) DEFAULT NULL COMMENT '类别名称',
  PRIMARY KEY (`catalog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of catalog
-- ----------------------------

-- ----------------------------
-- Table structure for `orderinfo`
-- ----------------------------
DROP TABLE IF EXISTS `orderinfo`;
CREATE TABLE `orderinfo` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单id',
  `user_info` text NOT NULL COMMENT '下单用户详情',
  `order_create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '订单创建时间',
  `order_state` int(11) DEFAULT NULL COMMENT '订单状态',
  `payment_way` varchar(1024) DEFAULT NULL COMMENT '支付方式',
  `order_prices` float DEFAULT NULL COMMENT '订单总金额',
  `order_detail` text COMMENT '订单详情',
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderinfo
-- ----------------------------

-- ----------------------------
-- Table structure for `skuinfo`
-- ----------------------------
DROP TABLE IF EXISTS `skuinfo`;
CREATE TABLE `skuinfo` (
  `sku_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `sku_name` varchar(1024) NOT NULL COMMENT '商品名称',
  `sku_price` float NOT NULL COMMENT '商品单价',
  `sku_state` tinyint(4) DEFAULT NULL COMMENT '商品状态',
  `sku_up_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '上架时间',
  `catalog_id` int(11) DEFAULT NULL COMMENT '所属类别',
  `sku_images` varchar(1024) DEFAULT NULL COMMENT '商品图片',
  PRIMARY KEY (`sku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of skuinfo
-- ----------------------------

-- ----------------------------
-- Table structure for `useraddress`
-- ----------------------------
DROP TABLE IF EXISTS `useraddress`;
CREATE TABLE `useraddress` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `user_detail_id` varchar(8) NOT NULL,
  `openid` varchar(200) DEFAULT NULL,
  `user_info` text,
  `state` tinyint(2) DEFAULT '0' COMMENT '0可用\r\n-1不可用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of useraddress
-- ----------------------------
INSERT INTO `useraddress` VALUES ('1', '7pcOVg4u', '1122qxqx', '{\"address\":\"北京市海淀区\",\"phone\":\"15011112222\",\"name\":\"qx钱鑫\"}', '0');
INSERT INTO `useraddress` VALUES ('2', '8ljxOghx', 'wwee', '{\"address\":\"天津市海淀区\",\"phone\":\"19911112222\",\"name\":\"hh哈哈\"}', '0');
INSERT INTO `useraddress` VALUES ('3', 'vbjSE4Qo', 'wwee', '{\"name\":\"东北\",\"phone\":\"1122233\",\"address\":\"wweerr\"}', '-1');
INSERT INTO `useraddress` VALUES ('4', 'BJEfIR6W', '1122qxqx', '{\"address\":\"需儿88\",\"phone\":\"12312322\",\"name\":\"发过的\"}', '0');

-- ----------------------------
-- Table structure for `userinfo`
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `login_name` varchar(200) DEFAULT NULL COMMENT '登录名',
  `login_pwd` varchar(200) DEFAULT NULL COMMENT '登录密码',
  `login_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '用户登录时间',
  `wx_openid` varchar(200) DEFAULT NULL,
  `wx_user_detail_id` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
INSERT INTO `userinfo` VALUES ('4', null, null, '2019-10-24 20:12:44', '1122qxqx', '7pcOVg4u');
INSERT INTO `userinfo` VALUES ('5', null, null, '2019-10-24 20:14:30', 'wwee', '8ljxOghx');
INSERT INTO `userinfo` VALUES ('6', null, null, '2019-10-24 20:14:53', 'wwee', 'vbjSE4Qo');
INSERT INTO `userinfo` VALUES ('7', null, null, '2019-10-24 20:15:20', '1122qxqx', 'BJEfIR6W');
