//app.js
import {
  getLoginInfo, getUserAddrs
} from './utils/apis'
import {
  getCurrentAddress,
  coordFormat
} from './utils/util'
import {
  gcj02tobd09
} from './utils/coordtransform'
import distance from './utils/distance'
App({
  onLaunch: function () {
    //调用API从本地缓存中获取数据
    
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        this.code = res.code
        console.log("qwe<<", this.code)
        this.secondCode = res.code
        // this.appid = wx72197cddd73b1908    
        // this.appSecret =  63153e65ee06a335df1329fa5a97839c
        let surl = 'http://localhost:8083/dev/wx/jscode2session?js_code=' + this.code
        wx.request({
          url: surl,
          success: res2 => {
            this.openid = res2.data.openid
            console.log("--===qwe<<", this.openid)
            this.session_key = res2.data.session_key
            this.appId = res2.data.appId
            if (this.openidCallback) {
              this.openidCallback(res2.data.openid);
            }
            if (this.session_keyCallback) {
              this.session_keyCallback(res2.data.session_key);
            }
            if (this.appIdCallback) {
              this.appIdCallback(res2.data.appId);
            }
            let surl = this.globalData.uchains_url + '/walk/isregopenid?openid=' + this.openid

            wx.request({
              url: surl,
              success: res => {
                this.state = res.data.code
                if (this.stateCallback) {
                  this.stateCallback(res.data.code);
                }
              }
            })

          }
        })
      }
    })


  },


  globalData: {
    loginInfo: null,
    currentAddress: null
  },
  session_key: '',
  appId: '',
  state: '',
  openid: '',
})