package com.umf.admin.server.dao;

import com.umf.admin.server.entity.RolePermission;
import org.apache.ibatis.annotations.Mapper;

/**
 * 角色资源信息DAO操作接口
 * @author
 * @create 2017-11-29 11:50
 */
@Mapper
public interface RolePermissionDaoMapper extends BaseDaoMapper<RolePermission> {
}
