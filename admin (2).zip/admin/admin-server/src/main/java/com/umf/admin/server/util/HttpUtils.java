package com.umf.admin.server.util;

import org.apache.http.HttpEntity;
import org.apache.http.client.fluent.Request;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.Charset;

/**
 * @desc:
 * @author: hp
 * @date: 2018/3/8
 */
@Component
public class HttpUtils {

    private final static Logger LOG = LoggerFactory.getLogger(HttpUtils.class);

    private final static int DEFAULT_TIME_OUT = 5000;

    private String httpPost(String url, HttpEntity entity, String contentType, int connectTimeout, int socketTimeout) throws IOException {
        return Request
                .Post(url)
                .connectTimeout(connectTimeout)
                .socketTimeout(socketTimeout)
                .setHeader(HttpConstant.Header.CONTENT_TYPE, contentType)
                .body(entity)
                .execute()
                .returnContent()
                .asString(Charset.forName(Constant.Charset.UTF_8));
    }

    public String httpGet(String url) throws IOException {
        return Request
                .Get(url)
                .connectTimeout(DEFAULT_TIME_OUT)
                .socketTimeout(DEFAULT_TIME_OUT)
                .setHeader(HttpConstant.Header.CONTENT_TYPE, HttpConstant.ContentType.JSON)
                .execute()
                .returnContent()
                .asString(Charset.forName(Constant.Charset.UTF_8));
    }
}
