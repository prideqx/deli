package com.umf.admin.server.util;

import com.umf.admin.server.config.AppConfig;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.HtmlEmail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class EmailUtil {

	protected final Logger LOG = LoggerFactory.getLogger(EmailUtil.class);

	@Autowired
	private AppConfig config;

	public boolean sendEmail(String to, String subject, String msg) {
		String[] tos = new String[]{to};
		return sendEmail(tos, null, subject, msg, null);
	}

	public boolean sendEmail(String[] tos, String subject, String msg) {
		return sendEmail(tos, null, subject, msg, null);
	}

	public boolean sendEmail(String[] tos, String[] ccs, String subject, String msg) {
		return sendEmail(tos, ccs, subject, msg, null);
	}

	public boolean sendEmail(String[] tos,String[] ccs,String subject, String msg, File file){
		try {
			HtmlEmail email = new HtmlEmail();
			email.setCharset(Constant.Charset.UTF_8);
			email.setHostName(config.getEmailHostName());
			email.setFrom(config.getEmailFrom());
			email.setAuthentication(config.getEmailUsername(), config.getEmailPassword());
			if(null == tos){
				return false;
			}
			for (String to : tos) {
				email.addTo(to);
			}
			if (null != ccs) {
				for (String cc : ccs) {
					email.addCc(cc);
				}
			}
			email.setSubject(subject);
			email.setMsg(msg);
			if (file != null) {
				EmailAttachment attachment = new EmailAttachment();
				attachment.setDescription("");
				attachment.setName(file.getName());
				attachment.setPath(file.getPath());
				email.attach(attachment);
			}
			email.send();
			LOG.info("Email发送成功 - 发送人员[{}] 抄送人员[{}]", Arrays.toString(tos), Arrays.toString(ccs));
			return true;
		} catch (Exception e) {
			LOG.warn("Email发送失败 - 发送人员[{}]-抄送人员[{}]", Arrays.toString(tos), Arrays.toString(ccs));
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			try {
				e.printStackTrace(pw);
				String errorContent = sw.toString();
				if(errorContent.indexOf("550 User not found")>0) {
					boolean flag = removeFailEmailAndSend(sw.toString(), tos, ccs, subject, msg, null);
					LOG.info("尝试剔除无效的Email再次发送[{}] ", flag ? "OK" : "FAIL");
				}
			} finally {
				pw.close();
			}
			return false;
		}
	}
	/**
	 * 剔除无效的邮件再次发送
	 */
	private boolean removeFailEmailAndSend(String errorLog, String[] tos,String[] ccs,String subject, String msg, File file) {
		final Pattern EMAILER = Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
		Matcher matchr = EMAILER.matcher(errorLog);
		
		List<String> failEmails = new ArrayList<String>();
        while (matchr.find()) {
            String email = matchr.group();
            failEmails.add(email);
        }

		LOG.warn("无效的Email[{}]", failEmails);
        
        List<String> hasErrorTos = new ArrayList<String>();
        List<String> hasErrorTcs = new ArrayList<String>();
        for (String hasErrorTo : tos) {
        	hasErrorTos.add(hasErrorTo);
        }
        for (String hasErrorTc : ccs) {
        	hasErrorTcs.add(hasErrorTc);
        }
        
        hasErrorTos.removeAll(failEmails);
        hasErrorTcs.removeAll(failEmails);
        
        String[] newTos = new String[hasErrorTos.size()];
        String[] newCcs = new String[hasErrorTcs.size()];
        
        for (int i=0; i<hasErrorTos.size(); i++) {
        	newTos[i] = hasErrorTos.get(i);
        }
        for (int i=0; i<hasErrorTcs.size(); i++) {
        	newCcs[i] = hasErrorTcs.get(i);
        }
        
        if(file != null) {
        	return sendEmail(newTos, newCcs, subject, msg, file);
        }else {
        	return sendEmail(newTos, newCcs, subject, msg);
		}
	}
	
	
	public static void main(String[] args) {
		EmailUtil e = new EmailUtil();
		String[] to = {"chengguangcan@umpay.com","chengguangcantest1@umpay.com","chengguangcantest2@umpay.com"};
		String[] cc = {"chengzhx76@qq.com"};
		e.sendEmail(to, cc, "Junit测试邮件", "JUnit邮件发送测试 <br><font size='13' color='red'>本封邮件为系统自动发出，请勿回复</font></br>");
		System.out.println("");
	}
}
