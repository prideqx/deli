package com.umf.admin.server.exception;


import com.umf.admin.server.response.StatusCodeEnum;

/**
 * 用户异常类
 * @author
 * @create 2017-11-29 10:22
 **/
public class UserException extends BaseException {
    public UserException() {
        super();
    }

    public UserException(String message) {
        super(message);
    }

    public UserException(StatusCodeEnum statusCode) {
        super(statusCode);
    }
    public UserException(StatusCodeEnum statusCode, String message) {
        super(statusCode, message);
    }
    public UserException(String message, Throwable ex) {
        super(message, ex);
    }

    /**
     * 默认的错误码返回
     * @return
     */
    @Override
    public StatusCodeEnum getStatusCode() {
        return super.statusCode != null ? super.statusCode : StatusCodeEnum.FAIL;
    }
}
