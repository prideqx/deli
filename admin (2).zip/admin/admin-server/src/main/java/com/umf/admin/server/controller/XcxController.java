package com.umf.admin.server.controller;

import com.alibaba.fastjson.JSONObject;
import com.umf.admin.server.dao.WxUserDaoMapper;
import com.umf.admin.server.entity.WxUser;
import com.umf.admin.server.response.Response;
import com.umf.admin.server.util.*;
import com.umf.springboot.encrypt.anno.Encrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 小程序
 */
@RestController
@RequestMapping("wx")
public class XcxController extends BaseController {

    @Autowired
    private WxUserDaoMapper wxUserDaoMapper;


    @GetMapping(value = "/jscode2session")
    public String jscode2session(@RequestParam(name = "js_code") String js_code) {
        String body = null;
        Map<String, String> map = new HashMap<>();
        map.put("appid", Constant.appid);
        map.put("secret", Constant.secret);
        map.put("js_code", js_code);
        map.put("grant_type", "authorization_code");
        body = HttpClientUtil.doGet(Constant.jscode2session, map);

        JSONObject jsonObject = JSONObject.parseObject(body);

        System.out.println("<><><jsonObject:"+jsonObject);
        String session_key = (String) jsonObject.get("session_key");
        jsonObject.put("appid", Constant.appid);
        //获取成功
        System.out.println("{}::"+jsonObject.toString());
        return jsonObject.toString();

    }

    @Encrypt
    @PostMapping("saveuser")
    public ResponseEntity<Response> saveUser(@RequestBody Map<String,Object> userMap) {

        String userDetailId = CodecUtils.createRandomAlphanumeric(8);
        String openId = (String) userMap.get("openid");
        Map<String ,String > rsMap = new HashMap<>();
        rsMap.put("openId",openId);
        rsMap.put("userDetailId",userDetailId);
        wxUserDaoMapper.saveUserInfo(rsMap);

        userMap.remove("openid");
        String userInfo = null;
        try {
            userInfo = JSONUtils.obj2json(userMap);
        } catch (Exception e) {
            e.printStackTrace();
        }
        wxUserDaoMapper.saveUserAddress(new WxUser(userDetailId, openId, userInfo));
        return success();
    }

    @Encrypt
    @GetMapping("selectAll")
    public ResponseEntity<Response> selectAll(String openid) {

        List<WxUser> wxUsers = wxUserDaoMapper.selectAllAddress(openid);
        for (WxUser wxUser:wxUsers) {
            String userInfo = wxUser.getUserInfo();
            JSONObject jsonObject = JSONObject.parseObject(userInfo);
            wxUser.setUserInfoJson(jsonObject);
        }
        System.out.println("wxUsers:"+wxUsers);
        return success(wxUsers);
    }

    /**
     * 根据id 和 userDetailId一起查  防止出问题
     * @param
     * @return
     */
    @Encrypt
    @GetMapping("selectOne")
    public ResponseEntity<Response> selectOne(String detailId) {

        WxUser wxUsers = wxUserDaoMapper.selectOne(detailId);
        String userInfo = wxUsers.getUserInfo();
        JSONObject jsonObject = JSONObject.parseObject(userInfo);
        wxUsers.setName((String) jsonObject.get("name"));
        wxUsers.setPhone((String) jsonObject.get("phone"));
        wxUsers.setAddress((String) jsonObject.get("address"));
        System.out.println("wxUsers:"+wxUsers);
        return success(wxUsers);
    }

    /**
     * 根据id 更新
     * @param userMap
     * @return
     */
    @Encrypt
    @PostMapping("updateOne")
    public ResponseEntity<Response> updateOne(@RequestBody Map<String,Object> userMap) {
        Map<String, Object> rsMap = new HashMap<>();
        rsMap.put("id",userMap.get("id"));
        userMap.remove("id");
        try {
            String userInfo = JSONUtils.obj2json(userMap);
            rsMap.put("userInfo",userInfo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        wxUserDaoMapper.updateOne(rsMap);
        return success();
    }

    @Encrypt
    @PostMapping("deleteOne")
    public ResponseEntity<Response> deleteOne(@RequestBody Map<String,Object> userMap) {

        wxUserDaoMapper.deleteOne(userMap);
        return success();
    }


}
