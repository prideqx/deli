package com.umf.admin.server.entity;

/**
 * 角色菜单关联类
 */
public class RoleMenu extends BaseEntity {
    private Integer roleId;
    private Integer menuId;

    public RoleMenu() {
    }

    public RoleMenu(Integer roleId) {
        this.roleId = roleId;
    }

    public RoleMenu(Integer roleId, Integer menuId) {
        this.roleId = roleId;
        this.menuId = menuId;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Integer getMenuId() {
        return menuId;
    }

    public void setMenuId(Integer menuId) {
        this.menuId = menuId;
    }
}
