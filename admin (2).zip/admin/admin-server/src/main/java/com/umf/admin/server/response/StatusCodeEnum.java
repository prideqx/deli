package com.umf.admin.server.response;


/**
 * Desc: Ajax 请求时的自定义查询状态码
 * Author: hp
 * Date: 2017-11-28
 */
public enum StatusCodeEnum {
    /** 请求成功 */
    OK(2000, "OK"),
    FAIL(5000, "内部错误"),
    ARGS_ERROR(5101, "参数错误"),
    ARGS_NOT_EMPTY(5102, "参数不能为空"),
    TOKEN_NOT_EMPTY(5103, "TOKEN不能为空"),

    EMAIL_FORMAT_ERROR(5104, "Email格式不正确"),
    /**用户模块响应码*/
    USER_INNER_ERROR(3000, "用户模块操作异常"),
    USER_NOT_EXIST(3001, "用户不存在或状态异常"),
    PASSWORD_NOT_CORRECT(3002, "用户密码不正确"),
    USER_ALREADY_LOGIN(3003, "用户已经登录"),
    TOKEN_NOT_CORRECT(3004, "用户Token不正确"),
    TOKEN_EXPIRE(3005, "登录过期"),
    USER_INVALID(3006, "无效的用户"),
    USER_EXIST(3007, "用户已存在"),
    ROLE_TX_NOT_FOUND(3008, "系统中没有交易角色"),

    /**账户模块响应码*/
    ACCOUNT_INNER_ERROR(4000, "账户信息操作异常"),
    ACCOUNT_CHAIN_ERROR(4010, "账户信息与所属链不匹配"),
    ACCOUNT_NOT_FOUND(4040, "没有该帐户"),
    ACCOUNT_TXS_OUT_NOT_FOUND(4041, "没有该输入帐户"),
    ACCOUNT_TXS_IN_NOT_FOUND(4042, "没有该输出帐户"),
    ACCOUNT_STATE_ABNORMAL(4050, "帐户状态异常"),
    ACCOUNT_TXS_OUT_STATE_ABNORMAL(4051, "输入帐户状态异常"),
    ACCOUNT_TXS_IN_STATE_ABNORMAL(4052, "输出帐户状态异常"),
    AMOUNT_BIG(4053, "超过最大金额"),


    SDK_ERROR(7000, "调用SDK出错"),
    UCHAINS_ERROR(8000, "业务出错"),

    HTTP_REQUEST_ERROR(6000, "请求出错"),

    /** 业务出错 **/
    REQUEST_ERROR(9000, "调用中间层出错"),
    PROCESS_ERROR(9001, "中间层处理出错"),
    RESPONSE_ERROR(9002, "请求响应返回错误"),
    DATA_ERROR(9003, "不是标准的JSON对象"),
    BLANK_ERROR(9004, "底层返回为空"),
    SIGN_ERROR(9100, "签名出错");



    private final Integer code;
    private final String message;

    StatusCodeEnum(Integer value, String message) {
        this.code = value;
        this.message = message;
    }

    public Integer code() {
        return this.code;
    }

    public String msg() {
        return this.message;
    }

}
