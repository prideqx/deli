package com.umf.admin.server.util;

/**
 * @desc:
 * @author: hp
 * @date: 2018/3/9
 */
public class HttpConstant {

    public static abstract class Method {

        public static final String GET = "GET";

        public static final String POST = "POST";

    }

    public static abstract class StatusCode {

        public static final int CODE_200 = 200;

    }

    public static abstract class Header {
        public static final String CONTENT_TYPE = "Content-Type";
        public static final String CONNECTION = "Connection";
    }

    public static abstract class HeaderValue {
        public static final String KEEP_ALIVE = "keep-alive";
    }

    public static abstract class ContentType {

        public static final String JSON = "application/json; charset=UTF-8";

        public static final String XML = "text/xml";

        public static final String FORM = "application/x-www-form-urlencoded; charset=UTF-8";

    }

}
