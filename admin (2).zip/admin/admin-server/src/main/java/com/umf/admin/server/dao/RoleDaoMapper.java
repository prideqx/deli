package com.umf.admin.server.dao;

import com.umf.admin.server.entity.Role;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 角色信息DAO操作接口
 * @author
 * @create 2017-11-29 11:50
 */
@Mapper
public interface RoleDaoMapper extends BaseDaoMapper<Role> {

    /**
     * 分页查询角色信息
     * @param role
     * @return
     */
    List<Role> findAllRoles(Role role);

    /**
     * 根据用户信息查询拥有角色
     * @param userId
     * @return
     */
    List<Role> getOwnRoleByUser(Integer userId);

    /**
     * 根据类型获取角色
     * @param type
     * @return
     */
    List<Role> getRoleByType(Integer type);

}
