package com.umf.admin.server.controller;

import com.umf.admin.server.exception.BaseException;
import com.umf.admin.server.exception.BusinessException;
import com.umf.admin.server.exception.IllegalParameterException;
import com.umf.admin.server.response.Meta;
import com.umf.admin.server.response.Response;
import com.umf.admin.server.response.StatusCodeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @desc:
 * @author: hp
 * @date: 2017/11/27
 */
public abstract class BaseController {

    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    //---------------- 成功 --------------------
    protected ResponseEntity<Response> success() {
        return setResponse(StatusCodeEnum.OK, StatusCodeEnum.OK.msg(), null);
    }

    protected ResponseEntity<Response> success(Object data) {
        return setResponse(StatusCodeEnum.OK, StatusCodeEnum.OK.msg(), data);
    }

    protected ResponseEntity<Response> success(String msg, Object data) {
        return setResponse(StatusCodeEnum.OK, msg, data);
    }

    //---------------- 失败 --------------------
    protected ResponseEntity<Response> failure() {
        return setResponse(StatusCodeEnum.FAIL, StatusCodeEnum.FAIL.msg(), null);
    }

    protected ResponseEntity<Response> failure(String msg) {
        return setResponse(StatusCodeEnum.FAIL, msg, null);
    }
    protected ResponseEntity<Response> failure(StatusCodeEnum statusCode) {
        return setResponse(statusCode, statusCode.msg(), null);
    }

    protected ResponseEntity<Response> failure(StatusCodeEnum statusCode, String msg) {
        return setResponse(statusCode, msg, null);
    }

    /**
     * 响应报文
     * @param statusCode 状态码
     * @param msg 消息
     * @param data 数据
     * @return 响应实体
     */
    private ResponseEntity<Response> setResponse(StatusCodeEnum statusCode, String msg, Object data) {
        return ResponseEntity.ok(new Response(statusCode.code(), msg, data));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Response> exceptionHandler(HttpServletRequest request, HttpServletResponse response, Exception ex) throws IOException {
        Meta meta = new Meta();
        if (ex instanceof IllegalArgumentException) { // 参数错误
            new IllegalParameterException(ex.getMessage()).handler(meta);
        } else if (ex instanceof BusinessException) { // http调用业务出错
            BusinessException businessEx = (BusinessException) ex;
            new BusinessException(businessEx.getCode(), businessEx.getMessage(), businessEx.getBusinessType()).handler(meta);
        } else if (ex instanceof BaseException) { // 最后捕获大的ex
            ((BaseException) ex).handler(meta);
        } else {
            meta.setCode(StatusCodeEnum.FAIL.code());
//            meta.setMsg(StatusCodeEnum.FAIL.msg());
            meta.setMsg(ex.getMessage());
        }
        LOG.error("发生异常==> {}", meta.getMsg(), ex);
        return ResponseEntity.ok(new Response(meta.getCode(), meta.getMsg(), null));
    }

}
