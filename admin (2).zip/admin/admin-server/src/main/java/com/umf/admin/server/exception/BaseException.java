package com.umf.admin.server.exception;

import com.umf.admin.server.response.Meta;
import com.umf.admin.server.response.StatusCodeEnum;
import org.apache.commons.lang3.StringUtils;

/**
 * @desc:
 * @author: hp
 * @date: 2017/11/27
 */
@SuppressWarnings("serial")
public abstract class BaseException extends RuntimeException {

	protected StatusCodeEnum statusCode;

	public BaseException() {
	}

	public BaseException(Throwable ex) {
		super(ex);
	}

	public BaseException(String message) {
		super(message);
	}
	public BaseException(StatusCodeEnum statusCode) {
		this.statusCode = statusCode;
	}
	public BaseException(StatusCodeEnum statusCode, String message) {
		super(message);
		this.statusCode = statusCode;
	}

	public BaseException(String message, Throwable ex) {
		super(message, ex);
	}

	public void handler(Meta meta) {
		meta.setCode(getStatusCode().code());
		if (StringUtils.isNotBlank(getMessage())) {
			meta.setMsg(getMessage()); // 取系统的错误消息
		}else {
			meta.setMsg(getStatusCode().msg());
		}
	}

	protected abstract StatusCodeEnum getStatusCode();
}
