package com.umf.admin.server.component;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


/**
 * 初始化操作类
 */
@Component
public class ApplicationInitRunner implements CommandLineRunner{

    @Override
    public void run(String... strings) throws Exception {

    }

}
