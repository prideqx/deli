package com.umf.admin.server.response;

import java.io.Serializable;

/**
 * @desc: 消息头
 * @author: hp
 * @date: 2017/11/14
 */
public class Meta implements Serializable {
    private static final long serialVersionUID = -6190165129774916252L;
    /** 状态码 **/
    private int code;
    /** 消息 **/
    private String msg;

    public Meta() {
    }

    public Meta(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
