package com.umf.admin.server.dao;

import com.umf.admin.server.entity.UserRole;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户角色信息DAO操作接口
 * @author
 * @create 2017-11-29 11:50
 */
@Mapper
public interface UserRoleDaoMapper extends BaseDaoMapper<UserRole> {
}
