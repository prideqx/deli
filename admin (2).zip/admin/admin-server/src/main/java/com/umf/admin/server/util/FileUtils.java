package com.umf.admin.server.util;

import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.*;
import java.util.List;

/**
 * @desc:
 * @author: hp
 * @date: 2017/12/26
 */
public class FileUtils extends org.apache.commons.io.FileUtils {
    public static String readFile(InputStream stream) throws IOException {
        List<String> contents = IOUtils.readLines(stream);
        StringBuffer sb = new StringBuffer();
        for (String content : contents) {
            if (content.charAt(0) != '-') {
                sb.append(content);
                sb.append("\r\n");
            }
        }
        return sb.toString();
    }
    public static String readResourceFileToString(String path) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(readResourceFileToInputStream(path)));
        String line = null;
        StringBuffer buffer = new StringBuffer();
        while ((line = reader.readLine()) != null) {
            if (line.charAt(0) != '-') {
                buffer.append(line);
                buffer.append("\r\n");
            }
        }
        reader.close();
        return buffer.toString();
    }


    public static byte[] readResourceFileToByteArray(String path) throws IOException {
        InputStream in = readResourceFileToInputStream(path);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024 * 4];
        int n = 0;
        while ((n=in.read(buffer)) != -1) {
            out.write(buffer,0, n);
        }
        return out.toByteArray();
    }

    public static InputStream readResourceFileToInputStream(String path) throws IOException {
        Resource resource = new ClassPathResource(path);
        return resource.getInputStream();
    }

    public static String readFileToString(String path) throws IOException {
        byte[] bytes = readResourceFileToByteArray(path);
        return new String(bytes);
    }

}
