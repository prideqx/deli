package com.umf.admin.server.util;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Desc: Http和Servlet工具类
 * Author: Cheng
 * Date: 2017年11月27日
 */
public class ServletUtils {
    /**
     * 获取当期请求对象
     * @return
     */
    public static HttpServletRequest getRequest() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
    }

    public static HttpServletResponse getResponse() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
    }

    public static String currentUrl() {
        HttpServletRequest request = ServletUtils.getRequest();
//        return "http://"+request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/";
        return "http://"+request.getServerName() + request.getContextPath();
//        return "http://uptc.umpay.com/dev/";
    }
}
