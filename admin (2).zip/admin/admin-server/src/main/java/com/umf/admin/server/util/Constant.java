package com.umf.admin.server.util;

/**
 * @desc:
 * @author: hp
 * @date: 2017/12/25
 */
public class Constant {

    public final static String appid = "wx72197cddd73b1908";
    public final static String secret = "63153e65ee06a335df1329fa5a97839c";
    public static String jscode2session = "https://api.weixin.qq.com/sns/jscode2session";






    public final static String TRUE = "1";
    public final static String FALSE = "0";
    public final static int TRUE_INT = 1;
    public final static int FALSE_INT = 0;

    public final static String AND = "&";
    public final static String EQUAL_SIGN = "=";

    public final static String DEFAULT_OPENID = "wx";

    public static final String IP = "MID_SERVER_IP";
    public static final String PORT = "MID_SERVER_PORT";
    public static final String PRI_KEY_SERVER_IP = "PRI_KEY_SERVER_IP";
    public static final String PRI_KEY_SERVER_PORT = "PRI_KEY_SERVER_PORT";
    public static final String ANSIBLE_SERVER_IP = "ANSIBLE_SERVER_IP";
    public static final String ANSIBLE_SERVER_PORT = "ANSIBLE_SERVER_PORT";

    public static abstract class MockType {
        public final static String ALL = "all";
        public final static String NEVER = "never";
        public final static String FAIL = "fail";
    }

    public static abstract class State {
        public final static String SUCCESS = "0000"; // 成功
    }

    public static abstract class BusinessType {
        public final static String UCHAINS_SERVER = "1"; // 服务器
        public final static String PRIVATE_KEY_SERVER = "2"; // 私钥服务器
        public final static String ANSIBLE_SERVER = "3"; // ansible服务器
    }


    public static abstract class NodeState {
        public final static int RUNNABLE = 0;  // 可运行状态
//        public final static int STOPPED = 1;  // 停止
        public final static int RUNNING = 2;  // 运行中
        public final static int STARTING = 3;  // 启动中
    }

    public static abstract class UserState {
        public final static int INVALID = 0;  // 无效
        public final static int NORMAL = 1;   // 正常
        public final static int WAIT = 2;     // 待审核
        public final static int NOPASS = 3;   // 驳回
    }

    public static abstract class LoginWay {
        public final static String FORM = "FORM";
        public final static String WX = "wechat";
    }

    public static abstract class UserType {
        public final static int ADMIN_TYPE = 1; // 管理类型
        public final static int TX_TYPE = 2;    // 交易类型
        public final static int TX_ADMIN_TYPE = 3;    // 交易类型
    }

    public static abstract class RequestType {
        public static final String JSON = "json";
        public static final String XML = "xml";
        public static final String FORM = "form";
    }

    public static abstract class TxType {
        public static final int IN_OR_OUT = 0;  //
        public static final int IN = 1;
        public static final int OUT = 2;
    }

    public final static int GENETATE_ACCOUNT = 1;      // 创世账户
    public final static int ORDINARY_ACCOUNT = 0;      // 普通账户

    public static abstract class AccountState {
        public final static int INVALID = 0;    // 无效
        public final static int NORMAL = 1;     // 正常
        public final static int FREZZ = 2;    // 冻结
        public final static int NO_AUDIT = 3;    // 待审批
        public final static int AUDIT_NOPASS = 4;    // 驳回
    }

    public static abstract class LogType {
        public final static int TYPE_CANCEL = 0;    // 注销
        public final static int TYPE_UNFREZZ = 1;   // 解冻
        public final static int TYPE_FREZZ = 2;     // 冻结
        public final static int TYPE_PASS = 3;      // 审批通过
        public final static int TYPE_NOPASS = 4;    // 审批驳回
        public final static int TYPE_AUTH = 5;      // 添加授权
        public final static int TYPE_NOAUTH = 6;    // 取消授权
        public final static int TYPE_UPDATE = 7;    // 编辑
        public final static int TYPE_GENERATE = 8;  // 置为创世
    }

    public static abstract class Dictionary {
        public final static String SHOW = "show";
        public final static String SHOW_USERNAME = "showUsername";
        public final static String DEFAULT_PASSWORD = "defaultPassword";
        public final static String DEFAULT_AVATAR = "defaultAvatar";
        public final static String KEY = "privateKey";
//        public final static String TOKEN_EXP_TIME = "tokenExpTime";
    }

    public static abstract class URL {
        public final static String PBC_MEMBER_URL = "http://"+IP+":"+PORT+"/pbc/inspection/member";
        public final static String PBC_COMMIT_URL = "http://"+IP+":"+PORT+"/pbc/inspection/record";
        public final static String PBC_INFO_URL = "http://"+IP+":"+PORT+"/pbc/inspection/record";

        // 首页展示接口
        public final static String INDEX_CHAIN_INFO_URL = "http://"+IP+":"+PORT+"/UChains/chaintxs";
        public final static String INDEX_INVOKE_INFO_URL = "http://"+IP+":"+PORT+"/UChains/invokeinfo";
        public final static String INDEX_PEER_INFO_URL = "http://"+IP+":"+PORT+"/UChains/peerinfo"; //获取活跃节点IP列表
        public final static String INDEX_PEER_TEST_URL = "http://PEER"+IP+":"+PORT+"/UChains/slefpeerinfo"; // 节点详情
        public final static String INDEX_BASE_INFO_URL = "http://"+IP+":"+PORT+"/UChains/baseinfo";

        public final static String ORG_WHITELIST_URL = "http://"+IP+":"+PORT+"/nifa/orgcertcommit/1.json?METHOD=POST";
        public final static String ORG_BLACKLIST_URL = "http://"+IP+":"+PORT+"/nifa/orgcertdelete/1.json?METHOD=POST";
        public final static String ORG_CERT_URL = "http://"+IP+":"+PORT+"/nifa/orgcert/1.json?METHOD=GET&orgId=";
        public final static String NODE_WHITELIST_URL = "http://"+IP+":"+PORT+"/nifa/peercertcommit/1.json?METHOD=POST";
        public final static String NODE_BLACKLIST_URL = "http://"+IP+":"+PORT+"/nifa/peercertdelete/1.json?METHOD=POST";
        public final static String NODE_CERT_URL = "http://"+IP+":"+PORT+"/nifa/peercert/1.json?METHOD=GET&orgId=";

        // ansible交互接口
        public final static String ANSIBLE_NODE_ADD = "http://"+ANSIBLE_SERVER_IP+":"+ANSIBLE_SERVER_PORT+"/UChains/addnode";
        public final static String ANSIBLE_PUBKEY_GET = "http://"+ANSIBLE_SERVER_IP+":"+ANSIBLE_SERVER_PORT+"/UChains/getpubkey";
        public final static String ANSIBLE_NODE_START = "http://"+ANSIBLE_SERVER_IP+":"+ANSIBLE_SERVER_PORT+"/UChains/startnode";
        public final static String ANSIBLE_CONTRACT_UPGRADE = "http://"+ANSIBLE_SERVER_IP+":"+ANSIBLE_SERVER_PORT+"/UChains/upgrade";
        public final static String ANSIBLE_CONTRACT_HASH = "http://"+ANSIBLE_SERVER_IP+":"+ANSIBLE_SERVER_PORT+"/UChains/gethash";
        public final static String ANSIBLE_NODE_NETTYPE = "http://"+IP+":"+PORT+"/UChains/getnetype";

        public final static String MEMBERSHIP_URL = "http://"+IP+":"+PORT+"/UChains/memberinfo/membership";
        public final static String PUBKEY_LIST_URL = "http://"+IP+":"+PORT+"/UChains/memberinfo/membership/";

        // 链展示接口
        public final static String CHAIN_INFO_URL = "http://"+IP+":"+PORT+"/UChains/chainsinfo";
        public final static String BLOCK_INFO_URL = "http://"+IP+":"+PORT+"/UChains/newestblocks/:chainId";
        public final static String DETAIL_FOR_BLOCK_NUM = "http://"+IP+":"+PORT+"/UChains/block/:chainId/:num";
        public final static String DETAIL_FOR_TX_ID = "http://"+IP+":"+PORT+"/UChains/transaction/:chainId/:txid";

        public final static String UTXO_TRANSACTION = "http://"+IP+":"+PORT+"//UChains/asset/coupon/utxo/transaction";
        public final static String UTXO_UTXO = "http://"+IP+":"+PORT+"/UChains/asset/coupon/utxo/:address/:beginTime/:endTime/:beginIndex/:endIndex/:signer/:sign";
        public final static String UTXO_LIST = "http://"+IP+":"+PORT+"/UChains/asset/coupon/utxo/account/:address/:beginTime/:endTime/:txType/:beginIndex/:endIndex/:signer/:sign";

        // 合约接口
        public final static String CHAIN_REG_URL = "http://"+IP+":"+PORT+"/UChains/chain/chainmgr";
        public final static String CONTRACT_REGISTER = "http://"+IP+":"+PORT+"/UChains/contract/rest/conf/register/:chainId";
        public final static String CONTRACT_STATUS_UPDATE = "http://"+IP+":"+PORT+"/UChains/contract/rest/conf/status/update/:chainId/:regStatus";
        public final static String CONTRACT_INFO_UPDATE = "http://"+IP+":"+PORT+"/UChains/contract/rest/conf/info/update/:chainId";
        public final static String CONTRACT_REST_LIST = "http://"+IP+":"+PORT+"/UChains/contract/rest/conf/qry/:chainId/:chainIdHash/:status/:beginIndex/:pageSize";
        public final static String CONTRACT_VERSION_LIST = "http://"+IP+":"+PORT+"/UChains/contract/ver/conf/:chainId/:regChainId/:vStatus/:beginIndex/:pageSize";
        public final static String CONTRACT_VERSION_ADD = "http://"+IP+":"+PORT+"/UChains/contract/ver/entry/:chainId";

        // 私钥服务器
        public final static String KEYSERVER_GEN_KEY = "https://"+PRI_KEY_SERVER_IP+":"+PRI_KEY_SERVER_PORT+"/UChains/keyserver/key";
        public final static String KEYSERVER_SIGN = "https://"+PRI_KEY_SERVER_IP+":"+PRI_KEY_SERVER_PORT+"/UChains/keyserver/signature";
//        public final static String KEYSERVER_GEN_KEY = "https://"+IP+":"+PORT+"/UChains/keyserver/key";
//        public final static String KEYSERVER_SIGN = "https://"+IP+":"+PORT+"/UChains/keyserver/signature";
        public final static String KEYSERVER_GET_PUB_KEY = "http://"+IP+":"+PORT+"/UChains/keyserver/account/:account";
        public final static String KEYSERVER_KEY_COUNT = "http://"+IP+":"+PORT+"/UChains/keyserver/keycount";

        // 微信接口
        public final static String WECHAT_ACCESS_TOKEN = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=:appid&secret=:secret&code=:code&grant_type=authorization_code";
        public final static String WECHAT_AUTHORIZE = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=:appid&redirect_uri=:url&response_type=code&scope=snsapi_base&state=:state#wechat_redirect";

    }

    public static abstract class Charset {
        public final static String UTF_8 = "UTF-8";
    }

    public static abstract class Role {
        public final static int ADMIN = 1;   // 超级管理员
        public final static int TX = 2;      // 交易角色
        public final static int AUDIT = 3;   // 审核角色
        public final static int ENTERING = 4;// 录入角色
        public final static int STATE_NORMAL = 1;   // 角色默认状态：正常
        public final static int TYPE_ADMIN = 1;     // 角色类型：管理类型
        public final static int TYPE_TX = 2;        // 角色类型：交易类型
        public final static int TYPE_AUDIT = 3;     // 角色类型：审批类型
        public final static int TYPE_ENTRY = 4;     // 角色类型：录入类型
    }

    public static abstract class Menu {
        public final static int INVISIBLE = 0;   // 菜单不可见
    }

    public static abstract class Permission {
        public final static int RESOURCE = 1;   // 资源
        public final static int BUTTON = 2;     // 按钮

        public final static int INVISIBLE = 0;   // 资源不可见
    }

    public static abstract class Org {
        public final static int NO_AUDIT = 0;   // 未审核
        public final static int IS_AUDIT = 1;   // 已审核
    }

    public static abstract class Node {
        public final static int NO_AUDIT = 0;   // 未审核
        public final static int IS_AUDIT = 1;   // 已审核
    }

    public static abstract class Nifa {
        public final static int ORG_ADD = 1;    // 机构添加
        public final static int NODE_ADD = 2;   // 节点添加
    }

    public static abstract class AlgType {
        public final static int ECDSA = 1;  // ecdsa
        public final static int SM2 = 2;    // sm2
        public final static int RSA = 3;    // rsa
    }

    public static abstract class MemberType {
        public final static int WHITE_LIST = 0; // 白名单状态
        public final static int BLACK_LIST = 1; // 黑名单状态
    }

    public static abstract class AuditState {
        public final static int AUDIT_WAIT = 0;     // 待审核
        public final static int AUDIT_NOPASS = 1;   // 审核未通过
        public final static int AUDIT_PASS = 2;     // 审核通过
        public final static int ARCHIVE = 3;        // 归档
    }

    public static abstract class Regular {
        public final static String REGEX_MOBILE = "^1(3[0-9]|4[457]|5[012356789]|66|7[135678]|8[0-9]|9[89])[0-9]{8}$";
        public final static String REGEX_MOBILE2 = "^170[01356789][0-9]{7}$";
        public final static String REGEX_EMAIL = "^([a-zA-Z0-9]+[_|\\_|\\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\\_|\\.]?)*[a-zA-Z0-9]+\\.[a-zA-Z]{2,3}$";
    }
}
