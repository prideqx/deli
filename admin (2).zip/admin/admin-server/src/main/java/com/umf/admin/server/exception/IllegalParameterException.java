/**
 * 
 */
package com.umf.admin.server.exception;


import com.umf.admin.server.response.StatusCodeEnum;

/**
 * Desc: 异常 - 参数异常
 * Author: cheng
 * Date: 2016/6/21
 */
@SuppressWarnings("serial")
public class IllegalParameterException extends BaseException {
	public IllegalParameterException() {
	}

	public IllegalParameterException(Throwable ex) {
		super(ex);
	}

	public IllegalParameterException(String message) {
		super(message);
	}

	public IllegalParameterException(StatusCodeEnum statusCode) {
		super(statusCode);
	}
	public IllegalParameterException(StatusCodeEnum statusCode, String message) {
		super(statusCode, message);
	}
	public IllegalParameterException(String message, Throwable ex) {
		super(message, ex);
	}

	@Override
	protected StatusCodeEnum getStatusCode() {
		return super.statusCode != null ? super.statusCode : StatusCodeEnum.FAIL;
	}
}
