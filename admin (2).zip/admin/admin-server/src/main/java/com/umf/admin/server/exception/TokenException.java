package com.umf.admin.server.exception;


import com.umf.admin.server.response.StatusCodeEnum;

/**
 * @desc:
 * @author: hp
 * @date: 2017/11/27
 */
public class TokenException extends BaseException {
    public TokenException() {
        super();
    }

    public TokenException(String message) {
        super(message);
    }

    public TokenException(StatusCodeEnum statusCode) {
        super(statusCode);
    }
    public TokenException(StatusCodeEnum statusCode, String message) {
        super(statusCode, message);
    }
    public TokenException(String message, Throwable ex) {
        super(message, ex);
    }

    @Override
    protected StatusCodeEnum getStatusCode() {
        return super.statusCode != null ? super.statusCode : StatusCodeEnum.FAIL;
    }
}
