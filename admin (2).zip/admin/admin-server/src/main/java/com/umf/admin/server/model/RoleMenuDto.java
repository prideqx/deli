package com.umf.admin.server.model;

/**
 * Created by Administrator on 2018/4/3.
 */
public class RoleMenuDto {
    private Integer roleId;
    private String menuIds;

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public String getMenuIds() {
        return menuIds;
    }

    public void setMenuIds(String menuIds) {
        this.menuIds = menuIds;
    }
}
