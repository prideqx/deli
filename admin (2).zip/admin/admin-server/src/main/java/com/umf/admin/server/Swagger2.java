package com.umf.admin.server;

import com.google.common.base.Predicates;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import springfox.documentation.builders.*;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.Parameter;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;


/**
 * @desc:
 * @author: hp
 * @date: 2018/6/26
 */

@Configuration
@EnableSwagger2
public class Swagger2 extends WebMvcConfigurerAdapter {

    @Value("${uchains.swagger.show}")
    private boolean swaggerShow;

    /**
     * 全局设置Content Type，默认是application/json
     * 如果想只针对某个方法，则注释掉改语句，在特定的方法加上下面信息
     * @ApiOperation(consumes="application/x-www-form-urlencoded")
     */

    @Bean
    public Docket createRestApi() {
        ParameterBuilder param = new ParameterBuilder();
        param.name("X-Token")
                .defaultValue("82E3BFCB506449B2A5F2BEB189F6EE56")
                .modelRef(new ModelRef("string"))
                .parameterType("header")
                .required(true)
                .description("用户登录凭证")
                .build();

        ResponseMessage responseMsg = new ResponseMessageBuilder()
                .code(5000)
                .message("服务器内部错误")
//                .responseModel(new ModelRef("Response"))
                .build();
        List<Parameter> params = new ArrayList<>();
        List<ResponseMessage> responseMsgs = new ArrayList<>();

        responseMsgs.add(responseMsg);
        params.add(param.build());

        return new Docket(DocumentationType.SWAGGER_2)
                .enable(swaggerShow)
                .useDefaultResponseMessages(false)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.umf.admin.server.controller"))
                .paths(Predicates.or(
                        PathSelectors.ant("/user/**")
                ))
//                .paths(PathSelectors.ant("/chain/**"))
                .build()
                .produces(new HashSet<String>() {{
                    add("application/json");
                }})
                .consumes(new HashSet<String>() {{
                    add("application/json");
                }})
                .globalOperationParameters(params)
                .globalResponseMessage(RequestMethod.GET, responseMsgs)
                .globalResponseMessage(RequestMethod.POST, responseMsgs);
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("优链接口文档")
                .description("优链接口文档")
                .termsOfServiceUrl("http://localhost:8086/dev/")
                .version("1.0")
                .contact(new Contact("Cheng", "", "chengguangcan@umfintech.com"))
                .build();
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/");

        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }
}
