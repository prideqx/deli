package com.umf.admin.server.exception;


import com.umf.admin.server.response.Meta;
import com.umf.admin.server.response.StatusCodeEnum;
import com.umf.admin.server.util.Constant;
import com.umf.admin.server.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc:
 * @author: hp
 * @date: 2018/6/27
 */
public class BusinessException extends BaseException {

    private static Map<String, String> uChainsCodeMap = new HashMap<>();
    private static Map<String, String> privateKeyServerCodeMap = new HashMap<>();
    private static Map<String, String> ansibleServerCodeMap = new HashMap<>();

    static {
        uChainsCodeMap.put("0000", "执行成功");
        uChainsCodeMap.put("0001", "输入块高度错误");
        uChainsCodeMap.put("0002", "输入块高度错误");
        uChainsCodeMap.put("0003", "链类型错误");
        uChainsCodeMap.put("9999", "系统正忙");
        uChainsCodeMap.put("9998", "异常错误");
        uChainsCodeMap.put("9997", "签名验签错误");
        uChainsCodeMap.put("9996", "反序列化错误");
        uChainsCodeMap.put("9994", "链长度错误");
        uChainsCodeMap.put("9993", "权限不足");
        uChainsCodeMap.put("9992", "接口请求错误");
        uChainsCodeMap.put("9991", "链不存在");
        uChainsCodeMap.put("9990", "请求参数异常");
        uChainsCodeMap.put("9989", "应用检查异常");
        uChainsCodeMap.put("9988", "应用配置信息错误");
        uChainsCodeMap.put("9987", "账本错误");
        uChainsCodeMap.put("9986", "交易不存在");
        uChainsCodeMap.put("9985", "参数检查错误");
        uChainsCodeMap.put("9984", "应用接口初始化为空");
        uChainsCodeMap.put("9983", "错误码配置错误");
        uChainsCodeMap.put("9982", "数据类型无效");
        uChainsCodeMap.put("9980", "找不到该服务");
        uChainsCodeMap.put("9979", "结构体转换集合错误");
        uChainsCodeMap.put("9978", "集合转换结构体错误");
        uChainsCodeMap.put("9977", "交易池异常");
        uChainsCodeMap.put("9976", "读取索引表错误");
        uChainsCodeMap.put("9975", "读取块表错误");
        uChainsCodeMap.put("9974", "读取业务表错误");
        uChainsCodeMap.put("9973", "CHAIND 散列已存在");
        uChainsCodeMap.put("9972", "CHAIND 散列不存在");
        uChainsCodeMap.put("9971", "唯一标识不存在");
        uChainsCodeMap.put("9970", "获取Hash类型名称错误");
        uChainsCodeMap.put("9969", "根据算法类型获取公钥错误");
        uChainsCodeMap.put("9968", "CHAINID已存在");
        uChainsCodeMap.put("9967", "CHAINID存在未开启状态记录");
        uChainsCodeMap.put("9966", "CHAINID不存在未开启状态");
        uChainsCodeMap.put("9965", "链未启用错误");
        uChainsCodeMap.put("9964", "CHIANID不存在开启状态记录");
        uChainsCodeMap.put("9963", "合约文件有误");
        uChainsCodeMap.put("9962", "结束块号有误");
        uChainsCodeMap.put("9961", "未花费交易流水未找到");
        uChainsCodeMap.put("9960", "交易流水未找到");
        uChainsCodeMap.put("9959", "合约升级版本号已存在");

        privateKeyServerCodeMap.put("0000", "执行成功");
        privateKeyServerCodeMap.put("0001", "注册账户已存在");
        privateKeyServerCodeMap.put("0002", "注册算法类型错误");
        privateKeyServerCodeMap.put("0003", "账户不存在");
        privateKeyServerCodeMap.put("0004", "数据格式错误");
        privateKeyServerCodeMap.put("0005", "传入参数长度错误");
        privateKeyServerCodeMap.put("0006", "输入口令错误");
        privateKeyServerCodeMap.put("9999", "系统异常，请稍后再试");

        ansibleServerCodeMap.put("0000", "执行成功");
        ansibleServerCodeMap.put("6000", "证书文件不存在");
        ansibleServerCodeMap.put("6001", "证书文件解析失败");
        ansibleServerCodeMap.put("6002", "新增节点失败");
        ansibleServerCodeMap.put("6003", "启动节点失败");
        ansibleServerCodeMap.put("9999", "so文件不存在");
    }

    private String code;
    private String businessType;

    public BusinessException() {
        super();
    }

    public BusinessException(String code, String message) {
        super(message);
        this.code = code;
    }

    public BusinessException(String code, String message, String businessType) {
        super(message);
        this.code = code;
        this.businessType = businessType;
    }


    public BusinessException(StatusCodeEnum statusCode) {
        super(statusCode);
    }
    public BusinessException(StatusCodeEnum statusCode, String message) {
        super(statusCode, message);
    }
    public BusinessException(String message, Throwable ex) {
        super(message, ex);
    }

    @Override
    protected StatusCodeEnum getStatusCode() {
        return super.statusCode != null ? super.statusCode : StatusCodeEnum.UCHAINS_ERROR;
    }

    @Override
    public void handler(Meta meta) {
        meta.setCode(StatusCodeEnum.UCHAINS_ERROR.code());
        
        String msg = null;
        if (Constant.BusinessType.UCHAINS_SERVER.equals(businessType)) {
            msg = uChainsCodeMap.get(code);
        } else if (Constant.BusinessType.PRIVATE_KEY_SERVER.equals(businessType)) {
            msg = privateKeyServerCodeMap.get(code);
        } else if (Constant.BusinessType.ANSIBLE_SERVER.equals(businessType)){
            msg = ansibleServerCodeMap.get(code);
        }
        if (StringUtils.isNotBlank(msg)) {
            meta.setMsg(msg);
        } else {
            meta.setMsg(getMessage()); // 取系统的错误消息
        }
    }

    public String getCode() {
        return code;
    }

    public String getBusinessType() {
        return businessType;
    }
}
