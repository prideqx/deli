package com.umf.admin.server.util;

import java.util.Map;
import java.util.regex.Pattern;

import static com.umf.admin.server.util.Constant.EQUAL_SIGN;

/**
 * Author: Cheng
 * Date: 2016/1/27 0027
 */
public class StringUtils extends org.apache.commons.lang3.StringUtils {
    /**
     * 隐藏手机号 中间六位
     * @param phone
     * @return
     */
    public static String hidePhone(String phone) {
        return substring(phone, 0, 3) + "******" + substring(phone, phone.length()-2, phone.length());
    }

    public static String joinWith(Map<String, Object> map, String joiner) {
        StringBuffer joinStr  = new StringBuffer();
        for (String key : map.keySet()) {
            if (joinStr.length() != 0) {
                joinStr.append(joiner);
            }
            String val = String.valueOf(map.get(key));
            joinStr.append(key).append(EQUAL_SIGN).append(val == null ? "" : val);
        }
        return joinStr.toString();
    }


    /**
     * 校验手机号
     * @param phone
     * @return
     */
    public static boolean isMobile(String phone) {
        return Pattern.matches(Constant.Regular.REGEX_MOBILE, phone) || Pattern.matches(Constant.Regular.REGEX_MOBILE2, phone);
    }

    /**
     * 校验邮箱
     * @param email
     * @return
     */
    public static boolean isEmail(String email) {
        return Pattern.matches(Constant.Regular.REGEX_EMAIL, email);
    }

}
