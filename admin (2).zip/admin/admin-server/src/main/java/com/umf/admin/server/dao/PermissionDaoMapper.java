package com.umf.admin.server.dao;

import com.umf.admin.server.entity.Permission;
import com.umf.admin.server.entity.RolePermission;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * Desc: 权限信息处理DAO
 * Author: HouBaoling
 * Date: 2017/12/28
 */
@Mapper
public interface PermissionDaoMapper extends BaseDaoMapper<Permission> {

    /**
     * 根据条件获取信息
     * @param permission
     * @return
     */
    List<Permission> findAll(Permission permission);

    /**
     * 根据资源id修改资源为不可见
     * @param permission
     * @return
     */
    int updatePermission2Invisible(Permission permission);

    /**
     * 根据菜单id查询资源信息
     * @param parentId
     * @return
     */
    List<Permission> findPermissions(Integer parentId);

    /**
     * 根据角色id查询拥有的资源信息
     * @param rolePermission
     * @return
     */
    List<Permission> getOwnPermissions(RolePermission rolePermission);

}
