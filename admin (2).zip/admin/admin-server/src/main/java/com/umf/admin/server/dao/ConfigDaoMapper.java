package com.umf.admin.server.dao;

import com.umf.admin.server.entity.Config;
import org.apache.ibatis.annotations.Mapper;

/**
 * Desc: 数据字典
 * Author: CHENG
 * Date: 2018年4月14日 10:56:07
 */
@Mapper
public interface ConfigDaoMapper extends BaseDaoMapper<Config> {


}
