package com.umf.admin.server.entity;

import com.alibaba.fastjson.JSON;

import java.util.ArrayList;
import java.util.List;

/**
 * 菜单实体类
 */
public class WxUser extends BaseEntity {
    private int id;
    private String userDetailId;
    private String openId;
    private String userInfo;
    private int state;

    //冗余字段
    private JSON userInfoJson;
    private String name;
    private String phone;
    private String address;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public WxUser() {
    }

    public WxUser( String userDetailId, String openid, String userInfo) {
        this.userDetailId = userDetailId;
        this.openId = openid;
        this.userInfo = userInfo;
    }

    public JSON getUserInfoJson() {
        return userInfoJson;
    }

    public void setUserInfoJson(JSON userInfoJson) {
        this.userInfoJson = userInfoJson;
    }

    public int getId() {
        return id;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserDetailId() {
        return userDetailId;
    }

    public void setUserDetailId(String userDetailId) {
        this.userDetailId = userDetailId;
    }

    public String getOpenid() {
        return openId;
    }

    public void setOpenid(String openid) {
        this.openId = openid;
    }

    public String getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(String userInfo) {
        this.userInfo = userInfo;
    }
}
