package com.umf.admin.server.dao;

import com.umf.admin.server.entity.RoleMenu;
import org.apache.ibatis.annotations.Mapper;

/**
 * 角色菜单信息DAO操作接口
 * @author
 * @create 2017-11-29 11:50
 */
@Mapper
public interface RoleMenuDaoMapper extends BaseDaoMapper<RoleMenu> {

}
