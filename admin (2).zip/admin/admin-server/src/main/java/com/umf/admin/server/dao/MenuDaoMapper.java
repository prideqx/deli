package com.umf.admin.server.dao;

import com.umf.admin.server.entity.Menu;
import com.umf.admin.server.entity.RoleMenu;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * Desc: 菜单信息处理DAO
 * Author: HouBaoling
 * Date: 2017/12/28
 */
@Mapper
public interface MenuDaoMapper extends BaseDaoMapper<Menu> {

    /**
     * 获取所有父菜单
     * @return
     */
    List<Menu> getParentMenus();

    /**
     * 根据角色id获取拥有的父菜单
     * @return
     */
    List<Menu> getParentMenusByRoleId(Integer roleId);

    /**
     * 根据父菜单获取其所有子菜单
     * @param menu
     * @return
     */
    List<Menu> getChildMenus(Menu menu);

    /**
     * 根据角色id和父菜单获取拥有的子菜单
     * @param menu
     * @return
     */
    List<Menu> getChildMenusByRoleId(Menu menu);

    /**
     * 根据菜单id修改菜单为不可见
     * @param menu
     * @return
     */
    int updateMenu2Invisible(Menu menu);
}
