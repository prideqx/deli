package com.umf.admin.server.entity;

/**
 * @desc:
 * @author: hp
 * @date: 2018/4/14
 */
public class Config extends BaseEntity {
    private Boolean id;
    private String configKey;
    private String configValue;
    private String name;
    private Boolean type;
    private Boolean state;

    public Config() {
    }

    public Config(String configKey) {
        this.configKey = configKey;
    }

    public Config(Boolean type) {
        this.type = type;
    }

    public Config(String configKey, String configValue) {
        this.configKey = configKey;
        this.configValue = configValue;
    }

    public Boolean getId() {
        return id;
    }

    public void setId(Boolean id) {
        this.id = id;
    }

    public String getConfigKey() {
        return configKey;
    }

    public void setConfigKey(String configKey) {
        this.configKey = configKey;
    }

    public String getConfigValue() {
        return configValue;
    }

    public void setConfigValue(String configValue) {
        this.configValue = configValue;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getType() {
        return type;
    }

    public void setType(Boolean type) {
        this.type = type;
    }

    public Boolean getState() {
        return state;
    }

    public void setState(Boolean state) {
        this.state = state;
    }
}
