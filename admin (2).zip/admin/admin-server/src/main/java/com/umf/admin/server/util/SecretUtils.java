package com.umf.admin.server.util;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;

/**
 * Desc: 封装一些加密工具 密码的加密、验证
 * Author: 光灿
 * Date: 2016/7/9
 */
public class SecretUtils {

    private final static Logger LOG = LoggerFactory.getLogger(SecretUtils.class);

    /** Shiro 算法 **/
    public static final String HASH_ALGORITHM = "SHA-1";
    /** 盐值的大小 **/
    public static final int SALT_SIZE = 8;
    /** 迭代的次数 **/
    public static final int HASH_INTERATIONS = 1024;

    public static final String AES = "AES";
    public static final int KEY_SIZE = 128;

    /**
     * 生成密码，生成随机数的16为盐值并且经过1024次 SHA-1 Hash
     * @param plainPassword
     * @return
     */
    public static String entryptPassword(String plainPassword) {
        String plain = Encodes.unescapeHtml(plainPassword);
        byte[] salt = Digests.generateSalt(SALT_SIZE);
        byte[] hashPassword = Digests.sha1(plain.getBytes(), salt, HASH_INTERATIONS);
        return Encodes.encodeHex(salt)+Encodes.encodeHex(hashPassword);
    }

    /**
     * @param planinPassword 明文密码
     * @param password 加密的密码
     * @return 验证结果
     */
    public static boolean validatePassword(String planinPassword, String password) {
        String plain = Encodes.unescapeHtml(planinPassword);
        byte[] salt = Encodes.decodeHex(password.substring(0, 16));
        byte[] hashPassword = Digests.sha1(plain.getBytes(), salt, HASH_INTERATIONS);
        return password.equals(Encodes.encodeHex(salt)+Encodes.encodeHex(hashPassword));
    }

    public static void main(String[] args) {
        System.out.println(entryptPassword("111111"));
        System.out.println(validatePassword("111111", "cc063bf88dc5a626d535e0b74676d9cf014aa2f1bdc47d34fc417f3e"));
    }

    /**
     * 生成密钥
     * @param param 要加密的记录标识
     * @param factor 加密因子
     * @return
     */
    public static String getPrivateKey(String param, String factor) {
        String key = param + factor;
        return Base64.encodeBase64String(String.valueOf(key.hashCode()).getBytes());
    }

    /**
     * 使用 AES 进行加密
     * @param res 要加密的明文
     * @param key 密钥
     * @return
     */
    public static String encode(String res, String key) {
        return keyGeneratorES(res, key, true);
    }

    /**
     * 使用 AES 进行解密
     * @param res 要解密的密文
     * @param key 密钥
     * @return
     */
    public static String decode(String res, String key) {
        return keyGeneratorES(res, key, false);
    }

    private static String keyGeneratorES(String res, String key, boolean isEncode) {
        try {
            KeyGenerator kg = KeyGenerator.getInstance(AES);
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
            secureRandom.setSeed(key.getBytes());
            kg.init(KEY_SIZE, secureRandom);
            SecretKey sk = kg.generateKey();
            SecretKeySpec sks = new SecretKeySpec(sk.getEncoded(), AES);
            Cipher cipher = Cipher.getInstance(AES);
            if (isEncode) {
                cipher.init(Cipher.ENCRYPT_MODE, sks);
                byte[] resBytes = res.getBytes();
                return Encodes.encodeHex(cipher.doFinal(resBytes));
            } else {
                cipher.init(Cipher.DECRYPT_MODE, sks);
                return new String(cipher.doFinal(Encodes.decodeHex(res)));
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("加解密过程出错");
        }
    }

    /*public void inputstreamtofile(InputStream ins,File file){
        OutputStream os = new FileOutputStream(file);
        int bytesRead = 0;
        byte[] buffer = new byte[8192];
        while ((bytesRead = ins.read(buffer, 0, 8192)) != -1) {
            os.write(buffer, 0, bytesRead);
        }
        os.close();
        ins.close();
    }*/
}
