package com.umf.admin.server.dao;

import com.umf.admin.server.entity.Menu;
import com.umf.admin.server.entity.WxUser;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * Desc: 菜单信息处理DAO
 * Author: HouBaoling
 * Date: 2017/12/28
 */
@Mapper
public interface WxUserDaoMapper extends BaseDaoMapper<WxUser> {

    /**
     * 插入userinfo表
     * @return
     */
    void saveUserInfo(Map<String, String> map);

    /**
     * 插入useraddress表
     * @return
     */
    void saveUserAddress(WxUser wxUser);

    List<WxUser> selectAllAddress(String openid);

    WxUser selectOne(String detailId);

    void updateOne(Map<String,Object> userMap);

    void deleteOne(Map<String,Object> userMap);
}
