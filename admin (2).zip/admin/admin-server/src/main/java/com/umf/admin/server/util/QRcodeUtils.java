package com.umf.admin.server.util;

import com.google.zxing.*;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc:
 * @author: hp
 * @date: 2018/1/12
 */
public class QRcodeUtils {

    private final static Logger LOG = LoggerFactory.getLogger(QRcodeUtils.class);

    private static final Map<EncodeHintType, ErrorCorrectionLevel> encodeMap = new HashMap<>();
    private static final Map<DecodeHintType, ErrorCorrectionLevel> decodeMap=new HashMap<>();
    private static final String FORMAT = "png";
    private static final int SIZE = 260;

   /* public static void createQRCode(String data, String path) {
        File file = new File(path);
        if (!file.exists()) {
            file.mkdirs();
        }
        try {
            MatrixToImageWriter.writeToFile(
                    new MultiFormatWriter()
                            .encode(new String(data.getBytes(Constant.Charset.UTF_8), charset),
                                    BarcodeFormat.QR_CODE, size, size, encodeMap),
                    format, file);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }*/

    public static void createQRCode(String data) {
        HttpServletResponse resp = ServletUtils.getResponse();
        resp.setContentType("image/png");
        resp.setHeader("Pragma", "No-cache");
        resp.setHeader("Cache-Control", "no-cache");
        resp.setDateHeader("Expires", 0);
        OutputStream stream = null;
        try {
            stream = resp.getOutputStream();
        resp.reset();

            MatrixToImageWriter.writeToStream(
                    new MultiFormatWriter()
                            .encode(new String(data.getBytes(Constant.Charset.UTF_8), Constant.Charset.UTF_8),
                                    BarcodeFormat.QR_CODE, SIZE, SIZE, encodeMap),
                    FORMAT, stream);
        } catch (IOException | WriterException e) {
            LOG.error("生成验证码错误", e);
            throw new RuntimeException("生成验证码错误");
        } finally {
            try {
                if (stream != null) {
                    stream.flush();
                    stream.close();
                }

            } catch (IOException e) {
                stream = null;
            }
        }
    }

    public static String readQRCode(String filePath) throws IOException, NotFoundException {
        return new MultiFormatReader().decode(new BinaryBitmap(new HybridBinarizer(new BufferedImageLuminanceSource(ImageIO.read(new FileInputStream(filePath))))),decodeMap).getText();
    }

    public static void main(String [] arg){
//        String content = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx3abce5d82087dbcc&redirect_uri=http%3a%2f%2fuptc.umpay.com%2fuchains%2fwx%2fconfirm&response_type=code&scope=snsapi_base&state=1#wechat_redirect";
        String content = "http://uptc.umpay.com/test?state=69EFB731FF5A483CAAD221A07D53C1F7";
        try{
//            createQRCode(content,"E:\\222.png");
            System.out.println(readQRCode("E:\\222.png"));
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
