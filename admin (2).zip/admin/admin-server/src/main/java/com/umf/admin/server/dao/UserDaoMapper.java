package com.umf.admin.server.dao;

import com.umf.admin.server.entity.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 用户信息DAO操作接口
 * @author
 * @create 2017-11-29 11:50
 */
@Mapper
public interface UserDaoMapper extends BaseDaoMapper<User>{

    /**
     * 更新数据-用户管理
     * @param user
     * @return
     */
    int updateUserById(User user);

    /**
     * 根据条件查询用户
     * @param user
     * @return
     */
    List<User> findUsers(User user);

    /**
     * 根据openid获取用户
     * @param openid
     * @return
     */
    User loadByOpenid(String openid);
}
