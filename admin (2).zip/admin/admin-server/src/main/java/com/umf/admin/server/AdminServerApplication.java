package com.umf.admin.server;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.umf.admin.server.util.CodecUtils;
import com.umf.admin.server.util.JSONUtils;
import com.umf.springboot.encrypt.anno.EnableEncrypt;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc:
 * @author: hp
 * @date: 2018/3/8
 */
@EnableEncrypt
@SpringBootApplication
@EnableTransactionManagement
@MapperScan("com.umf.admin.server.dao")
public class AdminServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(AdminServerApplication.class, args);


//        String randomAlphanumeric = CodecUtils.createRandomAlphanumeric(8);
//        System.out.println("randomAlphanumeric:"+randomAlphanumeric);
        Map<Object,Object> result1 = new HashMap<>();
        result1.put("商品","猪耳朵");
        result1.put("数量","3");
        Map<Object,Object> result2 = new HashMap<>();
        result2.put("商品","鸡腿");
        result2.put("数量","5");
        try {
            ArrayList<Map<Object,Object>> rs = new ArrayList<>();
            rs.add(result1);
            rs.add(result2);
            String jsonStr1 = JSONUtils.obj2json(rs);
            System.out.println("::"+jsonStr1);
            JSONArray objects = JSONObject.parseArray(jsonStr1);
            System.out.println("[[]]"+objects);
            for(int i=0;i<objects.size();i++){
                Map x = (Map)objects.get(i);
                System.out.println("***"+x.get("商品"));
                System.out.println("***"+x.get("数量"));
            }

            String jsonStr = JSONUtils.obj2json(result1);
            System.out.println("<<<"+jsonStr);

            JSONObject jsonObject = JSONObject.parseObject(jsonStr);
            System.out.println(">>>"+jsonObject);
            String name = jsonObject.getString("姓名");
            System.out.println("<><><>"+name);


        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
