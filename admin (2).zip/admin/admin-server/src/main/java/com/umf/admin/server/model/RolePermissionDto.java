package com.umf.admin.server.model;

/**
 * Created by Administrator on 2018/4/3.
 */
public class RolePermissionDto {
    private Integer roleId;
    private Integer menuId;
    private String permIds;

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Integer getMenuId() {
        return menuId;
    }

    public void setMenuId(Integer menuId) {
        this.menuId = menuId;
    }

    public String getPermIds() {
        return permIds;
    }

    public void setPermIds(String permIds) {
        this.permIds = permIds;
    }
}
