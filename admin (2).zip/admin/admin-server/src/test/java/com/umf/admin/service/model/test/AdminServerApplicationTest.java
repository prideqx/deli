package com.umf.admin.service.model.test;

import com.umf.admin.server.AdminServerApplication;
import com.umf.admin.server.config.AppConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @desc:
 * @author: hp
 * @date: 2018/5/9
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = AdminServerApplication.class)
public class AdminServerApplicationTest {

    @Autowired
    private AppConfig config;


    @Test
    public void test01() {
    }
}
