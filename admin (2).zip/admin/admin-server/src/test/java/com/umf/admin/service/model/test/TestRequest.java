package com.umf.admin.service.model.test;

import com.umf.admin.server.util.Constant;
import org.apache.http.client.fluent.Request;

import java.io.IOException;
import java.nio.charset.Charset;

/**
 * @desc:
 * @author: hp
 * @date: 2018/3/9
 */
public class TestRequest {
    public static void main(String[] args) throws IOException {
        String url = "http://10.10.144.26:9051/pbc/inspection/record/test01111/task01111/dev01111";
        String content = Request.Get(url)
                .execute()
                .returnContent()
                .asString(Charset.forName(Constant.Charset.UTF_8));

        System.out.println(content);
    }
}
