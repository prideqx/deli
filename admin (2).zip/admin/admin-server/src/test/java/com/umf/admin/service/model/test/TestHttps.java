//package com.umf.admin.service.model.test;
//
//import com.umf.admin.server.util.HttpConstant;
//import org.apache.http.HttpEntity;
//import org.apache.http.client.config.RequestConfig;
//import org.apache.http.client.methods.CloseableHttpResponse;
//import org.apache.http.client.methods.HttpUriRequest;
//import org.apache.http.client.methods.RequestBuilder;
//import org.apache.http.config.Registry;
//import org.apache.http.config.RegistryBuilder;
//import org.apache.http.conn.socket.ConnectionSocketFactory;
//import org.apache.http.conn.socket.PlainConnectionSocketFactory;
//import org.apache.http.conn.ssl.NoopHostnameVerifier;
//import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
//import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
//import org.apache.http.impl.client.CloseableHttpClient;
//import org.apache.http.impl.client.HttpClientBuilder;
//import org.apache.http.impl.client.HttpClients;
//import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
//import org.apache.http.ssl.SSLContexts;
//import org.apache.http.util.EntityUtils;
//
//import javax.net.ssl.SSLContext;
//import java.io.File;
//import java.io.FileInputStream;
//import java.security.KeyStore;
//import java.security.SecureRandom;
//import java.util.concurrent.TimeUnit;
//
///**
// * @desc:
// * @author: hp
// * @date: 2018/4/25
// */
//public class TestHttps {
//    private static PoolingHttpClientConnectionManager secureConnectionManager;
//    private static HttpClientBuilder secureHttpBuilder = null;
//    private static int DEFAULT_MAX_CONNECTION = 5;
//    private static int TIME_LIVE_MIN = 2;
//
//    private static String CLIENT_KEY_STORE = "E:\\Idea\\golang\\src\\privServer\\rsa\\vp0\\clientKeyStore.p12";
//    private static String CLIENT_TRUST_KEY_STORE = "E:\\Idea\\golang\\src\\privServer\\rsa\\vp0\\caKeyStore.jks";
//    private static String CLIENT_KEY_STORE_PASSWORD = "123456";
//    private static String CLIENT_TRUST_KEY_STORE_PASSWORD = "123456";
//    private static String CLIENT_KEY_PASS = "123456";
//
//    static {
//        try {
//            KeyStore trustStore = KeyStore.getInstance("jks");
//            FileInputStream trustStoreInput = new FileInputStream(new File(CLIENT_TRUST_KEY_STORE));
//            trustStore.load(trustStoreInput, CLIENT_TRUST_KEY_STORE_PASSWORD.toCharArray());
//
//            KeyStore clientKeyStore = KeyStore.getInstance("pkcs12");
//            FileInputStream clientKeyStoreInput = new FileInputStream(new File(CLIENT_KEY_STORE));
//            clientKeyStore.load(clientKeyStoreInput, CLIENT_KEY_STORE_PASSWORD.toCharArray());
//
//            SSLContext sslContext = SSLContexts.custom()
//                    .loadTrustMaterial(trustStore, new TrustSelfSignedStrategy())
//                    .loadKeyMaterial(clientKeyStore, CLIENT_KEY_PASS.toCharArray())
//                    .setSecureRandom(new SecureRandom())
//                    .build();
//
//            SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(
//                    sslContext,
//                    new String[]{"SSLv3", "TLSv1", "TLSv1.1", "TLSv1.2"},
//                    null,
//                    new NoopHostnameVerifier());
//            ConnectionSocketFactory plainSocketFactory = new PlainConnectionSocketFactory();
//            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
//                    .register("http", plainSocketFactory)
//                    .register("https", sslSocketFactory)
//                    .build();
//
//            secureConnectionManager = new PoolingHttpClientConnectionManager(registry, null, null, null, TIME_LIVE_MIN, TimeUnit.MINUTES);
//            secureConnectionManager.setMaxTotal(DEFAULT_MAX_CONNECTION * 2);
//            secureConnectionManager.setDefaultMaxPerRoute(DEFAULT_MAX_CONNECTION);
//            secureHttpBuilder = HttpClients.custom().setConnectionManager(secureConnectionManager);
//        } catch (Exception e) {
//            throw new Error("Failed to initialize the server-side SSLContext", e);
//        }
//    }
//
//    private static CloseableHttpClient getHttpClient() throws Exception {
//        return secureHttpBuilder.build();
//    }
//
//    private static HttpUriRequest httpUriRequest(String url, String method, String contentType, HttpEntity entity, int timeOut, int connectTimeout) {
//        RequestBuilder requestBuilder = null;
//        if (HttpConstant.Method.POST.equals(method)) {
//            requestBuilder = RequestBuilder.post();
//            if (entity != null) {
//                requestBuilder.setEntity(entity);
//            }
//        } else {
//            requestBuilder = RequestBuilder.get();
//        }
//
//        requestBuilder.setUri(url);
//
//        requestBuilder.addHeader(HttpConstant.Header.CONTENT_TYPE, contentType);
//        requestBuilder.addHeader(HttpConstant.Header.CONNECTION, HttpConstant.HeaderValue.KEEP_ALIVE);
//
//        RequestConfig.Builder requestConfigBuilder = RequestConfig.custom();
//        requestConfigBuilder.setConnectionRequestTimeout(connectTimeout)
//                .setSocketTimeout(timeOut)
//                .setConnectTimeout(connectTimeout);
//
//        requestBuilder.setConfig(requestConfigBuilder.build());
//        HttpUriRequest httpUriRequest = requestBuilder.build();
//        return httpUriRequest;
//    }
//
//    public static HttpUriRequest request4Get(String url, String contentType, int connectTimeout, int timeOut) {
//        return httpUriRequest(url, HttpConstant.Method.GET, contentType, null, connectTimeout, timeOut);
//    }
//
//    public static HttpUriRequest request4Post(String url, HttpEntity entity, String contentType, int connectTimeout, int timeOut) {
//        return httpUriRequest(url, HttpConstant.Method.POST, contentType, entity, connectTimeout, timeOut);
//    }
//
//
//    public static void main(String[] args) throws Exception {
//        CloseableHttpResponse response = null;
//        try {
////            response = getHttpClient().execute(request4Get("https://localhost:7153/privServer",500, 500));
//            response = getHttpClient().execute(request4Get("http://120.92.36.160:7451/UChains/baseinfo", HttpConstant.ContentType.JSON,500, 500));
//            if (response.getStatusLine().getStatusCode() == 200) {
//                HttpEntity entity = response.getEntity();
//                String message = EntityUtils.toString(entity, "utf-8");
//                System.out.println(message);
//            } else {
//                System.out.println("请求失败");
//            }
//        } finally {
//            if (response != null) {
//                //ensure the connection is released back to pool
//                EntityUtils.consumeQuietly(response.getEntity());
//            }
//        }
//
//    }
//
//
//
//
//}
