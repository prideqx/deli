package com.umf.admin.service.model.test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * @desc:
 * @author: hp
 * @date: 2018/6/22
 */
public class TestThreadPool {
    static ExecutorService threadPool = Executors.newSingleThreadExecutor();

    public static void main(String[] args) {
        TestThreadPool pool = new TestThreadPool();
//        pool.execute("task-1");
//        pool.execute("task-2");
//        threadPool.shutdown();
//        pool.submit("task-3");
        Future<Integer> future = pool.submitCallable("task-3");
        System.out.println("----end");
        try {
            System.out.println(future.get());
            if (future.get() == -1) {
                System.out.println("----- -1");
            }
            System.out.println("update");
        } catch (InterruptedException e) {
            System.out.println("--------->1");
            e.printStackTrace();
        } catch (ExecutionException e) {
            System.out.println("--------->2");
            e.printStackTrace();
        } catch (RuntimeException e) {
            System.out.println("--------->3");
            e.printStackTrace();
        }
    }

    void execute(final String taskName) {
        threadPool.execute(new Runnable() {
            @Override
            public void run() {
                int i = 0;
                for (;;) {
                    if (i > 10) {
                        break;
                    }
                    System.out.println("execute " + taskName + " 检查----> " + Thread.currentThread().getName() + " " + i);
                    i++;
                    await(1000);
                }
            }
        });
    }

    void submit(final String taskName) {
        threadPool.submit(new Runnable() {
            @Override
            public void run() {
                int i = 0;
                for (;;) {
                    if (i > 10) {
                        break;
                    }
                    System.out.println("submit " + taskName + " 检查----> " + Thread.currentThread().getName() + " " + i);
                    i++;
                    await(1000);
                }
            }
        });
    }


    Future<Integer> submitCallable(final String taskName) {
        Future<Integer> data = threadPool.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                int i = 1;
                long time = 1000;
                while (true) {
                    if (i > 20) {
                        return -1;
                    }
                    System.out.println("submitCallable " + taskName + " 检查----> " + Thread.currentThread().getName() + " " + i + " " + System.currentTimeMillis());
                    if (i > 16) {
                        return 1;
                    }
                    // 每5次增加500毫秒
                    if (i%5 == 0) {
                        time+=500;
                    }
                    i++;
                    await(time);
                }

            }
        });
        return data;
    }


    void await(long time) {
        try {
            TimeUnit.MILLISECONDS.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    List<String> list = new ArrayList() {{
        add("d");
    }};
}
