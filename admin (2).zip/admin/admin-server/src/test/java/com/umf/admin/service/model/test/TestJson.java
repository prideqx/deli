package com.umf.admin.service.model.test;

import com.alibaba.fastjson.JSON;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc:
 * @author: hp
 * @date: 2018/5/3
 */
public class TestJson {
    public static void main(String[] args) {
//        System.out.println(JSON.parseObject(""));

        Map<String, String> map = new HashMap<>();
        map.put("1111","12323");
        map.put("111sss1","12sss323");

        System.out.println(JSON.toJSONString(map));
    }
}
