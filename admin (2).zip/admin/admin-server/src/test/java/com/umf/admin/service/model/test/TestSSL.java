package com.umf.admin.service.model.test;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;

/**
 * @desc:
 * @author: hp
 * @date: 2018/4/25
 */
public class TestSSL {

    private static KeyStore loadKeyStoreIntoInputStream(String keyStoreLocation, String  keyStorePassword, String type) throws IOException, KeyStoreException, CertificateException, NoSuchAlgorithmException {
        FileInputStream is = new FileInputStream(new File(keyStoreLocation));
        KeyStore keyStore = KeyStore.getInstance(type);
        keyStore.load(is, keyStorePassword.toCharArray());
        return keyStore;
    }

    public static void main(String[] args) throws IOException, CertificateException, NoSuchAlgorithmException, KeyStoreException, UnrecoverableKeyException, KeyManagementException {
        HttpClient httpClient = new DefaultHttpClient();

        KeyStore clientKeyStore = loadKeyStoreIntoInputStream("E:\\Idea\\golang\\src\\privServer\\rsa\\vp0\\clientKeyStore.p12", "123456", "pkcs12");
        KeyStore caKeyStore = loadKeyStoreIntoInputStream("E:\\Idea\\golang\\src\\privServer\\rsa\\vp0\\caKeyStore.jks", "123456", "jks");

        SSLSocketFactory sslSocketFactory = new SSLSocketFactory(clientKeyStore, "123456", caKeyStore);
        sslSocketFactory.setHostnameVerifier(new AllowAllHostnameVerifier());

        Scheme protocolScheme = new Scheme("HTTPS", 443, sslSocketFactory);
        httpClient.getConnectionManager().getSchemeRegistry().register(protocolScheme);

//        HttpPost request = new HttpPost("https://localhost:7153/privServer");
        HttpGet request = new HttpGet("https://localhost:7153/privServer");

        HttpResponse response = httpClient.execute(request);
        HttpEntity entity = response.getEntity();
        String body = EntityUtils.toString(entity);
        System.out.println(body);
        EntityUtils.consume(entity);



    }

}
