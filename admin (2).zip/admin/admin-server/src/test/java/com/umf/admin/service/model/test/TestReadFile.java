package com.umf.admin.service.model.test;

/**
 * @desc:
 * @author: hp
 * @date: 2018/3/8
 */
public class TestReadFile {
    public static void main(String[] args) {
        String keyPath = TestReadFile.class.getClassLoader().getResource("pbc/test1.pub").getPath();
        System.out.println(keyPath);
    }
}
