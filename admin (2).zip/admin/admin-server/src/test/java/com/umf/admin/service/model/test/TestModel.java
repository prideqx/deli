package com.umf.admin.service.model.test;

import com.alibaba.fastjson.JSON;
import com.umf.admin.server.entity.User;

/**
 * @desc:
 * @author: hp
 * @date: 2018/3/8
 */
public class TestModel {
    public static void main(String[] args) {
        User user = new User();
        user.setUsername("1");
        user.setPassword("1");
        System.out.println(JSON.toJSON(user));
    }
}
