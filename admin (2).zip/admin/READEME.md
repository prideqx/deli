mvn install:install-file -Dfile=umpay-commons-util-1.3.3.jar -DgroupId=com.umpay -DartifactId=commons-util -Dversion=1.3.3 -Dpackaging=jar 
mvn install:install-file -Dfile=umpay_factoringSDK_20171121.jar -DgroupId=com.umpay -DartifactId=factoringSDK -Dversion=20171121 -Dpackaging=jar
mvn install:install-file -Dfile=umpay_factoringSDK_20180312.jar -DgroupId=com.umpay -DartifactId=factoringSDK -Dversion=20180312 -Dpackaging=jar 
mvn install:install-file -Dfile=umpay_nifa-SDK_20180110.jar -DgroupId=com.umpay -DartifactId=nifa-SDK -Dversion=20180110 -Dpackaging=jar 


keytool -importcert -alias vp0ca -file txRootCA.crt -storetype jks -keystore caKeyStore.keystore

openssl pkcs12 -export -in vp0.crt -out clientKeyStore.p12 -inkey vp0.key -name vp0
